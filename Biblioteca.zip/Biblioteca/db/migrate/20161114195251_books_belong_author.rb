class BooksBelongAuthor < ActiveRecord::Migration
  def change
  end
end
