class Books < ActiveRecord::Migration
  def change
    
  end
end
